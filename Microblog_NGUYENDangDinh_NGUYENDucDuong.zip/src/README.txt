To test this client - sever system:
1. implement a database (database-setup.txt) and add your own values
2. Run class Server.java then Client.java

At the moment, our clients can publish a message/ ask for messages (with options).
We suppose that messages sent back to clients are not saved in the database.